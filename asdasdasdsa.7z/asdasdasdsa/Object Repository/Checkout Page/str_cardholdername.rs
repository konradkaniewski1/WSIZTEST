<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>str_cardholdername</name>
   <tag></tag>
   <elementGuidId>90ba7b92-561b-4453-9c86-264d29e03de9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>Marian Pazdzioch</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
