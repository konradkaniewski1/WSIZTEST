import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable


// Otworzenie strony w przegladarce

WebUI.openBrowser(rawUrl = GlobalVariable.url)

// Zmaksymalizowanie okna

WebUI.maximizeWindow()

// Wprowadzenie wartosci z pliku .csv

//WebUI.setText(findTestObject('Object Repository/Checkout Page/input_email'), Email)
WebUI.setText(findTestObject('Object Repository/Checkout Page/input_email'), findTestData("Dane").getValue(1,1))

// Wprowadzenie wartosci z pliku .csv
 
//WebUI.setText(findTestObject('Object Repository/Checkout Page/input_name'), Name)
WebUI.setText(findTestObject('Object Repository/Checkout Page/input_name'), findTestData("Dane").getValue(6,1))

// Wprowadzenie wartosci ze zmiennej globalnej
 
WebUI.setText(findTestObject('Object Repository/Checkout Page/textarea_address'), GlobalVariable.address)

// Wybranie wartosci select ze zmiennej globa
 
WebUI.selectOptionByValue(findTestObject('Object Repository/Checkout Page/select_cardtype'), GlobalVariable.cardtype, true)

// Wprowadzenie wartosci z pliku .csv
 
//WebUI.setText(findTestObject('Object Repository/Checkout Page/input_cardnumber'), Cardnumber)
WebUI.setText(findTestObject('Object Repository/Checkout Page/input_cardnumber'), findTestData("Dane").getValue(4,1))

// Wprowadzenie wartosci z pliku .csv
 
//WebUI.setText(findTestObject('Object Repository/Checkout Page/input_cardholder_name'), Cardholdername)
WebUI.setText(findTestObject('Object Repository/Checkout Page/input_cardholder_name'), findTestData("Dane").getValue(5,1))




// Wprowadzenie wartosci z pliku .csv
 
//WebUI.setText(findTestObject('Object Repository/Checkout Page/input_verification_code'), Vcode)
WebUI.setText(findTestObject('Object Repository/Checkout Page/input_verification_code'), findTestData("Dane").getValue(7,1))

WebUI.click(findTestObject('Object Repository/Checkout Page/button_Place Order'))

assert WebUI.getWindowTitle() == "Menu"

//WebUI.closeBrowser()

