package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object email
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object address
     
    /**
     * <p></p>
     */
    public static Object cardnumber
     
    /**
     * <p></p>
     */
    public static Object cardholdername
     
    /**
     * <p></p>
     */
    public static Object name
     
    /**
     * <p></p>
     */
    public static Object vcode
     
    /**
     * <p></p>
     */
    public static Object cardtype
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            email = selectedVariables['email']
            url = selectedVariables['url']
            address = selectedVariables['address']
            cardnumber = selectedVariables['cardnumber']
            cardholdername = selectedVariables['cardholdername']
            name = selectedVariables['name']
            vcode = selectedVariables['vcode']
            cardtype = selectedVariables['cardtype']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
