﻿
PASTEBIN
GO
API
TOOLS
FAQ
paste
dayton1
FREE
dayton1
 
SHARE
TWEET
Guest User
Untitled
A GUEST
JAN 13TH, 2021
3
NEVER
 3.21 KB
     
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
 
/*
 * Otwarcie przeglądarki
 */
WebUI.openBrowser('')
 
/*
 * Maksymalizacja okna przeglądarki
 */
WebUI.maximizeWindow()
 
/*
 * Wpisanie url
 */
WebUI.navigateToUrl('http://www.practiceselenium.com/')
 
/*
 * Wybranie opcji rejestracji
 */
WebUI.click(findTestObject('Object Repository/Check_out/button_checkout'))
 
/*
 * Uzupełnienie pola 'e-mail'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_email'), findTestData("TD").getValue(1,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_email')) == email
/*
 * Uzupełnienie pola 'name'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_name'),  findTestData("TD").getValue(2,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_name')) == name
/*
 * Uzupełnienie pola 'address'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/textarea_address'),  findTestData("TD").getValue(3,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/textarea_address')) == address
 
/*
 * Wybór rodzaju karty
 */
WebUI.selectOptionByValue(findTestObject('Object Repository/Check_out/select_cardtype'), 'Diners Club', true)
 
/*
 * Uzupełnienie pola 'card number'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_cardnumber'),  findTestData("TD").getValue(4,1))
//assert WebUI.getText(findTestObject('Object Repository/Check_out/input_cardnumber')) == card_number
 
/*
 * Uzupełnienie pola 'cardholder name'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_cardholder'),  findTestData("TD").getValue(5,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_cardholder')) == cardholder_name
 
/*
 * Uzupełnienie pola 'verication code'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_verification'), GlobalVariable.verification_id)
 
/*
 * Nacisnięcie przycisku 'place order'
 */
WebUI.click(findTestObject('Object Repository/Check_out/button_placeorder'))
 
/*
* Zamykanie przeglądarki
*/
WebUI.closeBrowser()
RAW Paste Data
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

/*
 * Otwarcie przeglądarki
 */
WebUI.openBrowser('')

/*
 * Maksymalizacja okna przeglądarki
 */
WebUI.maximizeWindow()

/*
 * Wpisanie url
 */
WebUI.navigateToUrl('http://www.practiceselenium.com/')

/*
 * Wybranie opcji rejestracji
 */
WebUI.click(findTestObject('Object Repository/Check_out/button_checkout'))

/*
 * Uzupełnienie pola 'e-mail'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_email'), findTestData("TD").getValue(1,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_email')) == email
/*
 * Uzupełnienie pola 'name'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_name'),  findTestData("TD").getValue(2,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_name')) == name
/*
 * Uzupełnienie pola 'address'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/textarea_address'),  findTestData("TD").getValue(3,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/textarea_address')) == address

/*
 * Wybór rodzaju karty
 */
WebUI.selectOptionByValue(findTestObject('Object Repository/Check_out/select_cardtype'), 'Diners Club', true)

/*
 * Uzupełnienie pola 'card number'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_cardnumber'),  findTestData("TD").getValue(4,1))
//assert WebUI.getText(findTestObject('Object Repository/Check_out/input_cardnumber')) == card_number

/*
 * Uzupełnienie pola 'cardholder name'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_cardholder'),  findTestData("TD").getValue(5,1))
assert WebUI.getText(findTestObject('Object Repository/Check_out/input_cardholder')) == 'cardholder_name

/*
 * Uzupełnienie pola 'verication code'
 */
WebUI.setText(findTestObject('Object Repository/Check_out/input_verification'), GlobalVariable.verification_id)

/*
 * Nacisnięcie przycisku 'place order'
 */
WebUI.click(findTestObject('Object Repository/Check_out/button_placeorder'))

/*
* Zamykanie przeglądarki
*/
WebUI.closeBrowser()
My Pastes
Untitled
4 years ago
druga
4 years ago
albania
4 years ago
Untitled
5 years ago
Untitled
5 years ago
GRUPA ALBANIA
5 years ago
GRUPA DRUGA
5 years ago
fb
5 years ago
Public Pastes
Untitled
Dart | 1 min ago
Security 1
HTML | 1 hour ago
PHP 1
PHP | 1 hour ago
MySQL 1
MySQL | 1 hour ago
salmon_flength_dis...
Python | 1 hour ago
pengembalian
PHP | 1 hour ago
Untitled
FreeBasic | 1 hour ago
Untitled
FreeBasic | 1 hour ago
create new paste  /  syntax languages  /  archive  /  faq  /  tools  /  night mode  /  api  /  scraping api
privacy statement  /  cookies policy  /  terms of serviceupdated  /  security disclosure  /  dmca  /  report abuse  /  contact

By using Pastebin.com you agree to our cookies policy to enhance your experience.
Site design & logo © 2021 Pastebin
We use cookies for various purposes including analytics. By continuing to use Pastebin, you agree to our use of cookies as described in the Cookies Policy.  OK, I Understand