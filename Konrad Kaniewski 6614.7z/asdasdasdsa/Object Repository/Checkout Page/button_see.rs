<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_see</name>
   <tag></tag>
   <elementGuidId>98ba789e-769b-4873-9b5e-02de4e6bff1f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span[class=&quot;button-content wsb-button-content&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>button[id='wsb-button-00000000-0000-0000-0000-000450914890']</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
